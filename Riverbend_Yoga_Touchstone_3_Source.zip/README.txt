Riverbend Yoga Studio — Touchstone 3

Open index.html with your IDE's static preview to navigate the four pages.
All four pages share styles.css. Media assets use relative paths.
The workshop form is a local demonstration and does not transmit data.
